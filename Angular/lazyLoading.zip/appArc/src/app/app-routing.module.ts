import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';

const routes: Routes = [
  { path: '', component: DashboardComponent},
  { path: 'productos', loadChildren: './modules/productos/productos.module#ProductosModule'},
  { path: 'pedidos', loadChildren: './modules/pedidos/pedidos.module#PedidosModule'},
  { path: 'cuentas', loadChildren: './modules/cuentas/cuentas.module#CuentasModule'},
  { path: 'cesta', loadChildren: './modules/cesta/cesta.module#CestaModule'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
